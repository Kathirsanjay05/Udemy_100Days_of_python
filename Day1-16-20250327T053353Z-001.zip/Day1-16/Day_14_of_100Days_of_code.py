#1.breakdown into smaller problems
#2.do the easiest task first
#3.turn the problem into comments
#4.write code -> Run code ->Fix code
#5.Next task



#Day 14 -project

#display art
from art import logo,vs
import random
import game_data
print(logo)
score =0
account_a = random.choice(data)
account_b =random,choice(data)


#format the game data into printable
def format_data(account):
    """format data in the game data"""
    account_name =account("name")
    account_desc =account("description")
    account_country =account("follower_country")
    return  f"{account_name} , {account_desc} from {account_country}"

#use if statements if user is correct
def check_answer(user_guess, account_count_a,account_count_b):
    if account_count_a > account_count_b:
        return user_guess =='a'
    else:
        return user_guess =='b'
#generate a random account from the game data


if account_a == account_b:
    account_b = random.choice(data)
    
    
print(f"compare A : {format_data(account_a)},")
print(vs)
print(f"Against B : {format_data(account_b)},")


#ask user for a guess
guess = input("Who has more follower A or B : "),lower()


#check if the user go it right
# -get the follower count of  each account
a_account_follower = account["follower_count"]
b_account_follower = account_b["follower_count"]
is_correct =check_anser(guess,a_account_follower,b_account_follower)

#give user feedback on their guess
# score keeping
if is_correct:
    score  +=1
    print(f"you're right , Currnt score {score}")
else:
    print(f"Sorry that wrong ,Final score {score}")






