#Day_7_of_100Days_of_code
import random
print("Welcome to the Hangman Game!")

words_list=['kathir','sanjay','robotic','enginneer']

stages=["0","1","2","3","4","5","6"]
game_over=False
lives=6
random_word=random.choice(words_list)
hide_random_word="" #using the underscore

for i in random_word:
    hide_random_word+="_ "
print(hide_random_word)
print(f"The number of letter in the word is {len(random_word)}!")
#give/add a clue/hint together the random_word

game_over=False
saved_letter=[]

while not game_over:
    display_letter=""
    user_input=input("Enter the letter you guessed it?".strip()).lower() #guessing letter form user
    for letter in random_word:
        if letter==user_input:
            display_letter+=letter
            saved_letter.append(letter)
        elif letter in saved_letter:
            display_letter+=letter
        else:
            display_letter+="_ "
            
    if user_input not in random_word:
        lives-=1
        if lives==0:
            game_over==True
            print("You Lose")
                
                
    if "_ " not in display_letter:
        game_over=True
        print("You Won")

    print(f"you have remaining {stages[lives]} lives left")
        
    print(display_letter)
    print(saved_letter)
    
