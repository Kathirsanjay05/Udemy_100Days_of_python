#Day_5_of_100Days_of_code
#For Loops,Range and code Blocks
#haveibeenpwned.com -> website check this our email
'''
fruits=['apple','banana','orange','grapes',]
for fruit in fruits:
    print(fruit)
    print(fruit + "pie")
print(fruits)

student_score=[-1,2,3,4,5,55,6,7,8,9]
total_score=sum(student_score)
print(total_score)
#finf=ding the total sum of the list
total=0
for i in range(0,len(student_score)):
    total+=student_score[i] #it the indiduval element in the list
print(total)

#finding thre largest number
d=0
for i in student_score:
    if i > d:
        d=i
print(d)

#finding the smallest number
for i in student_score:
    if i < d:
        d=i
print(d)

#range function

total=0
for i in range(1,101):
    total+=i
print(total)

total=0
for i in range(1,101,2):
    total+=i/2
print(total)

print(sum(i for i in range(1,101))) #how this code works i don't know


print((sum(i)  for i in range(1,101))) #how this code works i don't know
'''

#Final project of Day5
import random


letters=['a','b','c','d','e','d','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','A','B','C','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
numbers=['1','2','3','4','5','6','7','8','9','0']
symbols=['!','@','#','$','%','*','&','(',')']

print("Welcome to the pypassword Generator")
nr_letters=int(input("Enter the no_of_letters you want in your password?\n"))
nr_numbers=int(input("Enter the no_of_numbers you want in your password?\n"))
nr_symbols=int(input("Enter the no_of_symbols you want in your password?\n"))
'''
#Easy method
password=""
for i in range(0,nr_letters):
    password+=random.choice(letters)
    #password+=password1
for i in range(0,nr_numbers):
    password+=random.choice(numbers)
   # password+=password2
for i in range(0,nr_symbols):
    password+=random.choice(symbols)
    #password+=password3

print(password)
'''
'''
This code is !!!!
mixed_password=""
for i in range(1,len(password)+1):
    mixed_password+=random.choice(password)
    print(mixed_password)
  '''
'''  
#mixed_password=password1 +password2+password3     
print("1 character is printed :",random.choice(password)) #string do not support this shuffle so use choice 
#print(mixed_random_password)
'''
#hard level
password=[]
for i in range(0,nr_letters):
    password.append(random.choice(letters))
for i in range(0,nr_numbers):
    password.append(random.choice(numbers))
for i in range(0,nr_symbols):
    password.append(random.choice(symbols))

print(password)
random.shuffle(password) # if i print this directly it will give you a none as a output
print("after shuffle :",password)

passwords=''
for i in password:
    passwords+=i
#     passwords+=random.shuffle(i) ==> it give typeerror only concatenate str(not "None Type") to str
        
print("your strongest password is ",passwords)
    

























