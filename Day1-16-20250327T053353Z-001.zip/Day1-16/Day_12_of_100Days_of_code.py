'''

# global scope and local scope
enemies=1 # global scope
def india():
    enemies=2   #local scope
    print("inside",enemies)
    
india()
print("outside",enemies)


#local scope
global_scope=10
def qwerty():
    local_scope=5
    print("Inside of qwerty",local_scope)
    #global scope
    print("Inside of qwerty global scope is accessable",global_scope) 
    
qwerty()
print(global_scope)



# whatever we provide name to a variable or function it has local and global scopes and it works only with a function
#E.G:functions and Variables

def asdfg():
    print("asdfg function")
    def zxcvb():
        print("zxcvb function",global_scope)
    
    
asdfg() # only the  print("asdfg function") line will execute

''
#creating the local and global scopes is applicable for functions and variables it is not applicable for loops and conditional statement
#E.G:for loop,while loop,if/elif/else statements

# block scope

kathir=15
sanjay=["strong","calm","speed"]
def mnb():
    kathir_sanjay=''  # to avoid the error lint show's in pycharm
    #^|^ it is the good way of writing code
    if kathir < 10:
        kathir_sanjay=sanjay[0]
        
    print(kathir_sanjay)
    
mnb()
    
''

# how to modify global scope

enemies=2

#maximum avoid global scope because it create confusion between code and also error & bugs

def increase_enemies():
    global enemies
    enemies +=1
    print(f"inside function {enemies}")
    
increase_enemies()
''
# Alternate for modifying the global scope

enemies=2

def increase_enemies(enemy):
    return enemy+1

enem=increase_enemies(enemies)

print(enem) # it works perfectly

#python constants and global scope

#we can specificy global constants using the all uppercase as a variable name
#we didn't change the value in global constants

#Example: it name is all uppercase
PI=3.14
GOOGLE_URL="https...sommething"


#if i go after a long and use the global scope it show us in uppercase so that it can't be changed
#Example:

def my_fun():
    print(PI)
    print(GOOGLE_URL)
    
my_fun()

'''
#Day 12 project-Numnber guessing
from art import logo
print(logo)










































