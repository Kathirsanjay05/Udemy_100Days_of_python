'''
#1.Describe the problem
def my_fun():
    for i in range(1,21): #in thisthe range(1,21) then only the  print() executes 
        if i==20:              #because the range() takes from 1 to 19 not 20 
            print("you got it")
            
my_fun()

#2.Reproducing the bugs

#it has index error 
from random import randint

dice_images=['0','1','2','3','4','5']
dice_num=randint(1,5) #change the random number from 0 to 5
print(dice_images[dice_num])

#3.play computer

# here ther eis no space for 1994 because the condition is not declared
year=int(input("what is your birth year? :"))

if year > 1980 and year < 1994:
    print("you are milennial")
elif year >= 1994: # that i have changed from (year > 1994) to (year >= 1994)
    print("you are GenZ")
'

#4.Fix the errors
# here we use try and except method for making code durable
#it can also prevent crash our code
# it is mostly used based on a input or output from a user(mostly) or from a computer

try:
    age =int(input("what is you age ? :"))
except ValueError:
    print("you have typed an invalid response .please enter your age in numerical response E.g: 15.")
    age =int(input("what is you age ? :"))
 
 #it also have try ,except and raise 
# and we can use multiple exception 

if age > 18:
    print(f"you are can drive at {age}") #that i have didn't use f -string
''


#5.print is your friend
#HERE  I am using print statement to know where i did wrong !
# words_per_page=0 i use this variable for practicing the error also i didn't show any error
#i use dto assigned it to word_per_page == int(input()) so it shows 0 in totol_words

pages=int(input("enter the number of pages :"))
words_per_page =int(input("enter the number of words per page :"))
total_words =pages *words_per_page

print(f"pages = {pages}")
print(f"words_per_page = {words_per_page}")

print(total_words)
'''
from random import randint
#use a debugger

def mutate(a_list):
    b_list =[]
    for item in a_list:
        new_item =item *2
        new_item+=randint(1,10)
        #new_item += item
        b_list.append(new_item)
    print(new_item)

mutate([1,2,3,4,5,6,7,8,9])

#take a break COFFEE....!/nap/break


#Ask a friend HUMAN.....!



#Run Often ever small program


#ask stackOveraFlow








