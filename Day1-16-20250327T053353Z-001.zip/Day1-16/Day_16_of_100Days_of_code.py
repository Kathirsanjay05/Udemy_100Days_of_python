#oops used to reuse the function again and again  
'''
#for example i have  a restaturant and i here 3 people which are
#chief .....waiter.....cleaner

#oops is trying to model a real world object

#hoe to use oops concepts

now try to model the waiter
in that what waiter "has" is a "attribiutes" basically a 'variable' and  it not a free floating variable connecting to the object
e.g:
is_holding_plate =True
tables_responsible =[4,5,6]

and then what waiter "does" is a "method" basically a 'function ' and it not a free floating functing connecting to the object.
e.g.
def take_order(table, order):
    #take order to chef
def take_payment(amount):
    #add money to restaurant








