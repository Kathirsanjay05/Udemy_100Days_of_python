'''def qwerty(text):
    return text+text
def asdfgh(text):
    return text.title()
output=asdfgh(qwerty("hello")) # it uses input from another function's output
print(output)

#using return in a function
def format_name(f_name,l_name):
    if f_name=="" or l_name=="":
        return 
    formated_f_name=f_name.title()
    formated_l_name=l_name.title()
    return f"{formated_f_name} {formated_l_name}"


print(format_name(f_name="kaTHiR",l_name="sANjAy"))


# in this without calling the inner_function its runs when calling the outer_function because of the inner_function is inside the outer_function


def outer_function(a, b):
    def inner_function(c, d):
        return c + d
    return inner_function(a, b)
 
result = outer_function(5, 10)
print(result)

'''
#help(print)
from Day_10_of_100Days_of_code_logo import logo

def add(a,b):
    return a+b
def sub(a,b):
    return a-b
def mul(a,b):
    return a*b
def div(a,b):
    return a/b
def expo(a,b):
    return a**b

operations={
    "+":add,
    "-":sub,
    "*":mul,
    "/":div,
    "**":expo
    
    }

#print(operations["*"](4,8))

#the method i use here is called recursion

def calculator():
    print(logo)
    should_continue=True
    num1=float(input("What is the first number? :"))
    while should_continue:
        for symbol in operations:
            print(symbol)
        operations_symbol = input("Pick an operator :")
        num2=float(input("what is the next number? :"))
        answer=operations[operations_symbol](num1,num2)
        print(f"{num1} {operations_symbol} {num2} = {answer}")
        
        choice=input(f"type \"y\" to continue with this {answer} or type \"n\" to start over :")
        
        if choice=='y':
            num1=answer
        elif choice=='':
            quit()
        else:
            should_continue=False
            print("\n"*30)
            calculator()
    
calculator()
    
    
    
    
    
    















