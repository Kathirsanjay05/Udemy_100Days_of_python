#Dictionaries and Nesting
programming_dictionary={"Bug":"An error in a program",
                        "function":"A piece of code that can call over and over again",
                        "loop":"The action of doing something over and over again"
    }
'''
print(programming_dictionary)
#adding a new value
programming_dictionary["name"]="kathir sanjay K"
print(programming_dictionary)
#To wipe an entire dictionary

programming_dictionary={}
print(programming_dictionary)
#edit an item in a dictionary

programming_dictionary["Bug"]="A moth in my computer"

print(programming_dictionary)
''

#loop through a dictionary

for i in programming_dictionary:
    print(i) #this prints the key of the dictionary
    print(programming_dictionary[i]) #this print the value of dictionary
print(programming_dictionary) #this print the entire dictionary 
'''
#Nesting and Dictionaries
'''
a={key1:[list],
   key2:{dict},
   key3:(tuple)
    }'

travel_log={
    "france":["lille","paris","dijong"],
    "germany":["berlin","stuttgart"]
    }
print(["france"][0])

nested_list=["a","b","c",["d","e","f"]]
print(nested_list[3][2])

travel_log_update={
    "france":{
        "cities_visited":["paris","lilles","dijong"],
        "total_visits":5
        },
    "germany":{
        "cities_visited":["berlin","stuttgart"],
        "total_visit":8
        }    
    }

print(travel_log_update["germany"]["cities_visited"][1])
'''
#Day 9 Final Project
#function for finding highest number
def find_higgest_bidder(bidding_dictionary):
    highest_amount=0 # for saving the integer value from the dictionary (value)amount(integer)
    winner=""   # for saving the string value from the dictionary value (key)
    for bidder in bidding_dictionary: #looping through  the dictionary
        bid_amount=bidding_dictionary[bidder] #getting the valu from the dictionary the key indexing
        if highest_amount < bid_amount: #checking the value with the highest_amount
            #always remember that when you print a value that is assigned by a variable that should be in left side
            highest_amount=bid_amount #setting the value to a new a value (highest)
            winner=bidder #setting the key to a new key(winner)
            
    print(f"The winner is {winner} and bidded amount of ${highest_amount}")
    
#creating an empty dictionary for storing all the values    
bids={}

continue_bidding=True

while continue_bidding:
    name=input("what is your name? :")
    price=int(input("what is your bid amount? : $"))
    should_continue=input("Do you want to continue 'yes' or 'no' ?".strip()).lower()
    bids[name]=price  #set the key and value to the dictionary (bids)
    if should_continue=='no':
        continue_bidding=False
        find_higgest_bidder(bids)
    elif should_continue=='yes':
        print("\n" *50)
    











