#Data types,Numbers,Operations,Type conversion,f-strings

#data types
'''
    *Integers
    *Strings
    *Float
    *Boolean
    
    
print("Hello"[0]) #indexing

print("Hello"[1:4]) #Slicing
print("123"+"345")

#Integers
print(123+223)
print(123_34+34_34_343_03) #the underscore are ignored

#Float
print(12.54)

#Boolean
print(False or True) # the computer take true the most as its priority


#Type Errors,Type checking,Type conversion

#print(len(12345)) #Type error

#Type checking
num_char =len(input("enter your name!")) #it automatically converts into interger except using int() when using len function
print(type(num_char))

#Type conversion

new_num_char=str(num_char)
print("your name has "+new_num_char+" characters")

print(100 +float("100.5"))
print(str(10)+str(0o0)) #0o0 - 0,0o01 - 1 # it does take 0 in the two part

#adding two digit integer
two_digit=input("enter the no you want to add :")
print(int(two_digit[0])+int(two_digit[1])) #23 =>2+3=5

#MAthematical Operations
print(3+1, addition
4-2, subtraction
44*2,	multiplication
34/2,   division  gives floating points
56//4,   floor division 
23**2,   power 
8%5,sep=",")
#calculation goes from left to right
print(3*3+4-2//9-3)
print(3*3+3/3-3)
print(3*(3+3)/3-3) #it removes the negative sign


#Bmi calculator

height=float(input("Enter your height in cms:"))
weight=int(input("enter your weight:"))
print(weight/(height*height))

#Number Manipulator

print(round(8/3,2))
instead we can use
print({:.2f}) most of the time go to this method

#f-string
score=10
height=183
winning=True
print(f"your score is {score} ,your height is {height}, you are winning is {winning}")

#Life in weeks

age=int(input("Enter your age:"))
life =90-age
weeks=52*life
print(f"you have {weeks} weeks left to live in this cursed world")
'''
#Day2 Project - Tip Calculator

bill=float(input("enter the total amount:"))
tip=int(input("Enter the tip you want to give 10% 12% 15&:"))
person=int(input("Enter the no of person you want to split with tips:"))
person_not_tips=int(input("Enter the no of person don't want to give tips:"))

if person<person_not_tips:
    print("It doesn't exits . Try again!")
    exit()

if person==1 and person_not_tips==1:
    print("doesn't available for same person. Try again!")
    exit()

if person==person_not_tips:
    print("It can't be same . Try again!")
    exit()
    


bill_per_person=bill/(person+person_not_tips)
remaining_amount=bill_per_person*person_not_tips
total_bill=bill-remaining_amount
tip_indiduval=tip/100*total_bill/person
tip =tip/100*total_bill+total_bill # here i accidently use dynamic typing

bill_per_person_with_tips = tip / person
print(f"person don't want to give tip will pay {bill_per_person:.2f}")
print(f"tip each person shares ${tip_indiduval:.2f}")
print(f"Each person should pay ${bill_per_person_with_tips:.2f}")






