'''
help()
    module spam
help("string")

#type help() and run this will you the modules and keyword when need to access type "modules spam"
#after help() was executed

    FUNCTIONS
    capwords(s, sep=None)
        capwords(s [,sep]) -> string
        
        Split the argument into words using split, capitalize each
        word using capitalize, and join the capitalized words using
        join.  If the optional second argument sep is absent or None,
        runs of whitespace characters are replaced by a single space
        and leading and trailing whitespace are removed, otherwise
        sep is used to split and join the words.

DATA
    __all__ = ['ascii_letters', 'ascii_lowercase', 'ascii_uppercase', 'cap...
    ascii_letters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    ascii_lowercase = 'abcdefghijklmnopqrstuvwxyz'
    ascii_uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    digits = '0123456789'
    hexdigits = '0123456789abcdefABCDEF'
    octdigits = '01234567'
    printable = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTU...
    punctuation = '!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'
    whitespace = ' \t\n\r\x0b\x0c'
    
    print(chr(2949)) #0xbb5 This is called as unicode

Range           Decimal     Name
0x0A00-0x0A7F   2560-2687   Gurmukhi
0x0A80-0x0AFF   2688-2815   Gujarati
0x0B00-0x0B7F   2816-2943   Oriya
0x0B80-0x0BFF   2944-3071   Tamil

print("HELLO \n kathir \rsanjay") #when i run lisk this the output is sanjayr
print("HELLO \n kathir \r sanjay") #when i run lisk this the output is HELLO sanjay

print("HELLO \n kathir \x0b sanjay") #when i run lisk this the output is HELLO kathir  sanjay
print("HELLO \n kathir \x0c sanjay") #when i run lisk this the output is HELLO HELLO  kathir  sanjay


#conditional statements,Logical operators, code blocks and scope
#remember != this is not equal to symbol
# '=' - assign, '==' - check equality


Exercise
num=int(input("Enter the number you want to check whether \"Odd or Even\":"))
if num%2==0:
    print(f"The number {num} is Even")
else:
    print(f"The number {num} is Odd")
    
    

print("BMI Calculator")

weight=int(input("Enter your weight in kg:"))
height=float(input("Enter your height in cms:"))/100
bmi=weight/(height*height)

if bmi<18.5:
    print(f"you are bmi is {bmi} & you are underweight")
elif bmi<25:
    print(f"you are bmi is {bmi} & you are normal")
elif bmi<30:
    print(f"you are bmi is {bmi} & you are overweight")
elif bmi<35:
    print(f"you are bmi is {bmi} & you are Obese")
else:
    print(f"you are bmi is {bmi} & you are Clinically Obese")

#Exercise
#leap year program
num=int(input("Enter the number:"))
if num%4==0:
    if num%100==0:
        if num%400==0:
            print(f"This year {num} is a Leap year")
        else:
            print(f"This year {num} is Not a leap year")
    else:
        print(f"This year {num} is a leap year")
else:
    print(f"This year {num} is not a leap year")


# Control Flow
#Roller coaster program
print("Welcome to roller coaster!")
height=int(input("Enter your height in cms:"))
if height >=120:
    print("You can ride")
    age =int(input("Enter your age:"))
    #Nested If /elif /else statements
    if age<12:
        bill=5
        #print("You need to Pay:$5")
    elif age<=18:
        bill=7
        #print("You need to Pay:$7")
    elif age>=45 and age<=55:
        bill=0
        #print("Have a free ride")
    elif age>60:
        print("Sorry you can't ride")
        #we can't leave the if /elif/else of the condition statement's inside block empty
        #we need pass something like print,variable ,loops, if/elif/else statements
    else:
        bill=12
        #print("You need to Pay:$12")
    want_photos=input("Do you want photos [Y/N]?").lower()
    #write the lower function outside the parenthesis for converting input to lowercase
    #Don't write/use code like this ->input("enter num".lower())
    if want_photos=='y':
        if age>=45 and age<=55:
            bill=0
            print(f"your bill is {bill} , @Lucky Day!")
            exit() # alteranate is quit()
        bill+=3
        print(f"your bill is ${bill}")
    else:
        print(f"your bill is ${bill}")
else:
    print("Sorry you need to grow little tall")
    


#Exercise
#Pizza order

print("Pizza Ordering Bill")

size=input("What size of Pizza Do you Want [\"S\",\"M\",\"L\"]?").lower()
add_peporine=input("Do you want to add peporine [\"Y\",\"N\"]?").lower()
extra_cheese=input("Do you want to [\"Y\",\"N\"]?").lower()

if size=="s":
    bill=15
elif size=="m":
    bill=20
else:
    bill=25
    
if add_peporine=="y":
    bill+=3
    
if extra_cheese=="y":
    bill+=1

print(f"your bill is {bill}")    

''
#Exercise
#love calculator
print("Welcome to the Love Calculator")
name1=input("Enter your name!:").lower()
name2=input("Enter your partner name!:").lower()
combined_name=name1+name2
t=combined_name.count("t")
r=combined_name.count("r")
u=combined_name.count("u")
e=combined_name.count("e")

first_digit=t+r+u+e

l=combined_name.count("l")
o=combined_name.count("o")
v=combined_name.count("v")
e=combined_name.count("e")

second_digit=l+o+v+e

total_score=int(str(first_digit)+str(second_digit))

if total_score<10 or total_score>90:
    print(f"you are score is {total_score} & you are like coke and mentos")
elif total_score>=40 and total_score<=50:
    print(f"you are score is {total_score} & you are like together")
else:
    print(f"your score is {total_score}")
'''

#Day 3 -Final Project
#Treasure hunter

print("Welcome to the treasure Island")
print("Your mission is to find the treasure")
l1=input("your are now at cross ,where do you go? \n \t  Type \"left\" or \"right\"\n:").strip().lower() #this split operation do's split every string seprate by a comma and affastafy
if l1=="left":
    l2=input("you've come to a lake.There is island middle in the lake.\n\tType \"wait\" wait for a boat or Type \"swim\" to swim across\n:").strip().lower()
    #["you've", 'come', 'to', 'a', 'lake.There', 'is', 'island', 'middle', 'in', 'the', 'lake.', 'Type', '"wait"', 'wait', 'for', 'a', 'boat', 'or', 'Type', '"swim"', 'to', 'swim', 'across']
    #if i define any functions thing inside the parenthesis it only does for the inside of the paranthesis.
    if l2=="wait":
        l3=input("you arrive at the island unharmed. There is a house with 3 doors.\n\t one red, one blue, one yellow.Which one do you choose?:\n:").strip().lower()
        if l3=="red":
            print("It's a room full of fire.Game over.")
        elif l3=="yellow":
            print("You found the treasure. you win!")
        elif l3=="blue":
            print("You enter a room of beasts.Game over")
        else:
            print("Invalid answer")
    elif l2=="swim":
        print("You get attacked by an angry trout.Game over")
    else:
        print("Invalid answer")
elif l1=="right":
    print("You fell into a hole.Game Over")
else:
    print("Invalid answer")
        



























    

    

    
