#Day 11 - project Blackjack

import random

# create an function for choosing random card for both user
def deal_card():
    cards=[11,2,3,4,5,6,7,8,9,10,10,10,10]
    card=random.choice(cards)
    return card

#create an function for calculating the score for both user

def calculate_score(cards):
    if sum(cards) == 21 and len(cards) == 2:
        return 0

    if 11 in cards and len(cards) >2 and sum(cards) > 10 : 
        cards.remove(11)
        cards.append(1)

    return sum(cards)

#create an function for comparing the score of both user


def compare(u_score , c_score):
    if u_score==c_score:
        return "Draw"
    elif u_score ==0:
        return  "Win with a BlackJack"
    elif c_score==0:
        return "Oppenent has a BlackJack"
    elif u_score > 21:
        return "You went over , you lose"
    elif c_score >21:
        return "opponent went over . you win"
    elif u_score > c_score:
        return "you win "
    else:
        return "you lose"

# creating an function for the whole process in that game
def play_game():
    user_card=[]
    computer_card=[]
    computer_score=-1
    user_score=-1
    is_game_over=False 

    #picking the cards from the deck twice using for loop

    for _ in range(2):
        user_card.append(deal_card())
        computer_card.append(deal_card())

     #runs the game
    
    while not is_game_over:
        user_score=calculate_score(user_card) # storing the calculated value in a varible  called user_score
        computer_score=calculate_score(computer_card) # storing the calculated value in a varible  called computer_score
        print(f"Your cards are : {user_card}  and your score is {user_score}")
        print(f"Computer card first card is {computer_card[0]}")
        
        #conditioning the process procedure 
        
        if user_score==0 or computer_score==0 or user_score >21:
            is_game_over=True
        else:
            user_dealing=input("Type 'y' to get an another card and 'n ' to pass :")
            if user_dealing=='y':
                user_card.append(deal_card())
            else:
                is_game_over=True
        
        #when computer need's a card 
        
    while  computer_score !=0 and computer_score <17:
        computer_card.append(deal_card())
        computer_score=calculate_score(computer_card)
        
    print(f"Your final cards are  {user_card}  and score is : {user_score}")
    print(f"Opponents final cards are  {computer_card}  and score is : {computer_score}")
    print(compare(user_score,computer_score))


# starting the game when it needed

while input("Do you want to play BlackJack Type 'y' or 'n' :")=='y':
    print("\n" * 30)
    play_game()


