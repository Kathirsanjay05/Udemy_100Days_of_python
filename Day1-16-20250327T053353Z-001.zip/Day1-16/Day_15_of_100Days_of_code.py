MENU={
    
    "espresso":{
        "ingredients":{
            "water":50,
            "coffee" :18,
            },
        "cost":1.5
        },
    "cappuccino":{
        "ingredients":{
            "water":250,
            "milk":100,
            "coffee":24
            },
        "cost":3.0
        },
    "latte":{
        "ingredients":{
            "water":200,
            "milk":150,
            "coffee":24            
            },
        "cost":2.4
        
        }
    }
profit=0
#pre- defining the resources
resources={
    "water":3000,
    "milk":2000,
    "coffee": 1000,
    
    }
#checking the resource available
def is_resources_sufficient(order_ingredient):
    for item in order_ingredient:
        if order_ingredient[item] >= resources[item]:
            print(f"Sorry there is not enough {item}")
            return False
    return True

#process the coins to dollors
def process_coins():
    """return the total calculated from coins inserted"""
    total =int(input("how many quarters? : ")) *0.25
    total +=int(input("how many dimes? : ")) *0.1
    total +=int(input("how many nickles? : ")) *0.05
    total +=int(input("how many pennies? : ")) *0.01
    return total


#check's  the transaction 
def is_transaction_successful(money_received,drink_cost):
    '''return true when the payment is succesful or false if the money is insufficient'''
    if money_received >= drink_cost:
        change = round(money_received - drink_cost,2)
        print(f"Here is your ${change} change")
        global profit
        profit +=drink_cost
        return True
    else:
        print("Sorry you don't have  enough money")
        return False
    
def make_coffee(drink_name , order_ingredients):
    '''detect the required ingredent from the  resources'''
    for item in  order_ingredients:
        resources[item] -= order_ingredients[item]
    print(f"Here is your {drink_name}☕. Enjoy!")
        

is_on =True

while is_on:
    choice= input("What would like ? (espresso/cappuccino/latte) : ").lower()
    # maintence keys are "off" and "report"
    if choice =="off":
        is_on =False
    elif choice == "report":
        print(f" water : {resources['water']}ml\n Milk :{resources['milk']}ml\n Coffee :{resources['coffee']}g\n Money :${profit}")
    else:
        drink =MENU[choice]
        if is_resources_sufficient(drink["ingredients"]):
            payment =process_coins()
            if is_transaction_successful(payment,drink["cost"]):
                make_coffee(choice,drink["ingredients"])
    