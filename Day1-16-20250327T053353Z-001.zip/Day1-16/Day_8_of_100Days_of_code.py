'''def something(name):
    print(f"your name is {name}")
    print(f"How are you {name} ")
m=input("Enter your name:")
something(m)
''
#Positional Argument

def something(name,location ):
    print(f"your name is {name}")
    print(f"Where are you {location} ")

something("sanjay","chennai") #first argument is assigned to first parameter
something("chennai","kathir")

#Keyword Argument
def something(name,location ):
    print(f"your name is {name}")
    print(f"Where are you {location} ")

something(name="sanjay",location="chennai")   # wherever the argument is .it is assigned to its parameter.
something(location="chennai",name="sanjay")  #whether the position is changed or not ,what the value is assigned to the parameter it is printed
'''
#Day -8 Project Caesar Cipher

alphabet=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
'''
a=len(alphabet)
print(a)
def encode(message,shift_number):
    encode_message=""
    for i in message:
        shifted_position=alphabet.index(i) + shift_number
        shifted_position%=len(alphabet)
        encode_message+=alphabet[shifted_position]
    print(encode_message)
    

def decode(message, shift_number):
    # i didn't use the same argument (text,shift)name here because it give warning Redefining name 'shift_number' from outer scope (line 50)
It looks like the local variable is hiding a global variable with the same name.
Most likely there is nothing wrong with this. I just wanted to remind you that you can't access the global variable like this. If you knew it then please ignore the warning.
If you don't want to see this reminder in the future, then add "redefined-outer-name" (without quotes) into "Tools → Options → Assistant → Disabled checks".
Line 37 : Redefining name 'shift_number' from outer scope (line 50)
    decode_message=""
    for i in message:
        shifted_position=alphapet.index(i) - shift_number 
        decode_message+=alphapet[shifted_position]
    print(decode_message)
'''   

def casear(message,shift_number,enc_or_dec):
    decode_message=""
    if enc_or_dec=="decode":
            shift_number *=-1
    else:
        print("You typed an invalid option!...try again")
        quit()
    for i in message:
        if i not in alphabet:
            decode_message+=i
        else:
            shifted_position=alphabet.index(i) + shift_number
            shifted_position%=len(alphabet)
            decode_message+=alphabet[shifted_position]
    print(f"Here the {enc_or_dec}d message : \"{decode_message}\"")
    

encode_or_decode=True
while encode_or_decode:
    direction=input("what do you want \"Encode\" or \"Decode\" :".strip()).lower()
    text=input("enter the message :".strip()).lower()
    shift=int(input("enter the shift number you want :"))
    
    casear(text,shift,direction)
    stop=input("Do you want to continue \"yes\" or \"No\"/ [Y/N] :".strip()).lower()   
    if stop=='n': # it  doesn't work for double quotes
        encode_or_decode=False
        print("The Operation is finished")
        
        
        
        
        
        
        
        
# help(decode(message,shift_number)) # this doesn't work for our usesr defined functions














































































