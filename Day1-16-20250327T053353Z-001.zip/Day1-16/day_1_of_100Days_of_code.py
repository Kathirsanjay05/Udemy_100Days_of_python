'''#string manipulation

print("she said :\"hello\" and then left !")

print('she said :"hello" and left')

print("Hello"+ ' kathir')

print("HELLO \n kathir\vsanjay")

help()
    module spam
help("string")

#type help() and run this will you the modules and keyword when need to access type "modules spam"
#after help() was executed

    FUNCTIONS
    capwords(s, sep=None)
        capwords(s [,sep]) -> string
        
        Split the argument into words using split, capitalize each
        word using capitalize, and join the capitalized words using
        join.  If the optional second argument sep is absent or None,
        runs of whitespace characters are replaced by a single space
        and leading and trailing whitespace are removed, otherwise
        sep is used to split and join the words.

DATA
    __all__ = ['ascii_letters', 'ascii_lowercase', 'ascii_uppercase', 'cap...
    ascii_letters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    ascii_lowercase = 'abcdefghijklmnopqrstuvwxyz'
    ascii_uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    digits = '0123456789'
    hexdigits = '0123456789abcdefABCDEF'
    octdigits = '01234567'
    printable = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTU...
    punctuation = '!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'
    whitespace = ' \t\n\r\x0b\x0c'
    
    

print("HELLO \n kathir \rsanjay") #when i run lisk this the output is sanjayr
print("HELLO \n kathir \r sanjay") #when i run lisk this the output is HELLO sanjay

print("HELLO \n kathir \x0b sanjay") #when i run lisk this the output is HELLO kathir  sanjay
print("HELLO \n kathir \x0c sanjay") #when i run lisk this the output is HELLO HELLO  kathir  sanjay


#\v --it has this and a space
#\f - 
#\b -remove the before one letter
#\n -print in next line

print("Kathir"+ input("Enter your last name:"))

#Variables

name=input("enter your name?")
print(name)

#len() function

print(len(name))

#this will work but don't use input as variable name
#input=input("enter your name!")

# creating of the day1 project

'''
"""Band width generator"""
print("Welcome to band name generator") 
city=input("Enter the city your grown up?")
pet=input("Enter your pet name?")
nick_name=city+" "+pet
print(nick_name)












